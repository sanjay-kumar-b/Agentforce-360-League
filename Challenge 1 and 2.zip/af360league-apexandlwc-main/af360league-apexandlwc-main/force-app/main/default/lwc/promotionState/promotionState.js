import { defineState } from "@lwc/state";

const promotionStateManager = defineState(
  ({ atom, computed, setAtom }) => {

    const promotionName = atom('');
    const chosenProducts = atom([]);
    const chosenStores = atom([]);

    const addProduct = (product) => {
        let chosenProductsTemp = chosenProducts.value;
        chosenProductsTemp.push(product);
        setAtom(chosenProducts, chosenProductsTemp);
    };

    const removeProduct = (product) => {
        let chosenProductsTemp = chosenProducts.value;
        chosenProductsTemp.splice(chosenProductsTemp.indexOf(product), 1);
        setAtom(chosenProducts, chosenProductsTemp);
    };

    const productCount = computed([chosenProducts], (products) => products.length);

    const updateStores = (stores) => {
        setAtom(chosenStores, stores);
    };

    const updatePromotionName = (name) => {
        setAtom(promotionName, name);
    };

    // Return an object that defines the public API of counterManager
    return {
      promotionName,
      chosenProducts,
      addProduct,
      removeProduct,
      productCount,
      updateStores,
      updatePromotionName
    };
  },
);

export default promotionStateManager;