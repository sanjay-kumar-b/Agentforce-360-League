import { defineState } from "@lwc/state";

const promotionStateManager = defineState(
  ({ atom, computed, setAtom }) => {

    // Create a state property to store promotion name
    const promotionName = atom('');

    // create a state property of type array to store products
        // Products stored as: { productId, productName, category, discountPercent, isSelected }
        
    const chosenProducts = atom([]);
    const chosenStores = atom([]);

    // Add or update a product with discount
    const setProduct = (product) => {
        let chosenProductsTemp = [...chosenProducts.value];
        const existingIndex = chosenProductsTemp.findIndex(p => p.productId === product.productId);

        const normalizedProduct = {
            productId: product.productId,
            productName: product.productName,
            category: product.category,
            discountPercent: product.discountPercent ?? 0,
            isSelected: true
        };

        if (existingIndex >= 0) {
            chosenProductsTemp[existingIndex] = { ...chosenProductsTemp[existingIndex], ...normalizedProduct };
        } else {
            chosenProductsTemp.push(normalizedProduct);
        }
        
        setAtom(chosenProducts, chosenProductsTemp);
    };

    // Remove a product by ID
    const removeProduct = (productId) => {
        let chosenProductsTemp = chosenProducts.value.filter(p => p.productId !== productId);
        setAtom(chosenProducts, chosenProductsTemp);
    };

    // const removeProduct = (productId) => {
    //     const updatedProducts = chosenProducts.value.map(p =>
    //         p.productId === productId
    //             ? { ...p, isSelected: false }
    //             : p
    //     );

    //     setAtom(chosenProducts, updatedProducts);
    // };

    // Bulk update products (replaces entire selection)
    const updateProducts = (products) => {
        setAtom(chosenProducts, [...products]);
    };

    // Check if a product is selected
    const isProductSelected = (productId) => {
        return chosenProducts.value.some(p => p.productId === productId);
    };

    // const isProductSelected = (productId) => {
    //     return chosenProducts.value.some(
    //         p => p.productId === productId && p.isSelected
    //     );
    // };

    // Get discount for a product
    const getProductDiscount = (productId) => {
        const product = chosenProducts.value.find(p => p.productId === productId);
        return product ? product.discountPercent : 0;
    };

    const productCount = computed(
        [chosenProducts],
        (products) => products.length
    );

    // const productCount = computed(
    //     [chosenProducts],
    //     (products) => products.filter(p => p.isSelected).length
    // );

    const updateStores = (stores) => {
        setAtom(chosenStores, [...stores]);
    };

    const updatePromotionName = (name) => {
        setAtom(promotionName, name);
    };

    // Return an object that defines the public API of promotionStateManager
    return {
      promotionName,
      chosenProducts,
      setProduct,
      removeProduct,
      updateProducts,
      isProductSelected,
      getProductDiscount,
      productCount,
      chosenStores,
      updateStores,
      updatePromotionName
    };
  },
);

export default promotionStateManager;